﻿namespace PatientRecords
{
    partial class MedicalHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbMedicalHistory = new System.Windows.Forms.GroupBox();
            this.gbAllergies = new System.Windows.Forms.GroupBox();
            this.gbWomen = new System.Windows.Forms.GroupBox();
            this.gbIllnesses = new System.Windows.Forms.GroupBox();
            this.radioButton113 = new System.Windows.Forms.RadioButton();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.radioButton114 = new System.Windows.Forms.RadioButton();
            this.label49 = new System.Windows.Forms.Label();
            this.radioButton115 = new System.Windows.Forms.RadioButton();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.radioButton116 = new System.Windows.Forms.RadioButton();
            this.radioButton117 = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.radioButton118 = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radioButton119 = new System.Windows.Forms.RadioButton();
            this.radioButton120 = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.radioButton121 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton122 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButton123 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButton124 = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.radioButton125 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButton126 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.gbMedicalHistory.SuspendLayout();
            this.gbAllergies.SuspendLayout();
            this.gbWomen.SuspendLayout();
            this.gbIllnesses.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbMedicalHistory
            // 
            this.gbMedicalHistory.Controls.Add(this.textBox3);
            this.gbMedicalHistory.Controls.Add(this.label11);
            this.gbMedicalHistory.Controls.Add(this.radioButton113);
            this.gbMedicalHistory.Controls.Add(this.textBox6);
            this.gbMedicalHistory.Controls.Add(this.radioButton114);
            this.gbMedicalHistory.Controls.Add(this.label49);
            this.gbMedicalHistory.Controls.Add(this.radioButton115);
            this.gbMedicalHistory.Controls.Add(this.textBox4);
            this.gbMedicalHistory.Controls.Add(this.radioButton116);
            this.gbMedicalHistory.Controls.Add(this.radioButton117);
            this.gbMedicalHistory.Controls.Add(this.textBox2);
            this.gbMedicalHistory.Controls.Add(this.radioButton118);
            this.gbMedicalHistory.Controls.Add(this.textBox1);
            this.gbMedicalHistory.Controls.Add(this.radioButton119);
            this.gbMedicalHistory.Controls.Add(this.radioButton120);
            this.gbMedicalHistory.Controls.Add(this.comboBox1);
            this.gbMedicalHistory.Controls.Add(this.radioButton121);
            this.gbMedicalHistory.Controls.Add(this.label1);
            this.gbMedicalHistory.Controls.Add(this.radioButton122);
            this.gbMedicalHistory.Controls.Add(this.label2);
            this.gbMedicalHistory.Controls.Add(this.radioButton123);
            this.gbMedicalHistory.Controls.Add(this.label3);
            this.gbMedicalHistory.Controls.Add(this.radioButton124);
            this.gbMedicalHistory.Controls.Add(this.label20);
            this.gbMedicalHistory.Controls.Add(this.radioButton125);
            this.gbMedicalHistory.Controls.Add(this.label4);
            this.gbMedicalHistory.Controls.Add(this.radioButton126);
            this.gbMedicalHistory.Controls.Add(this.label5);
            this.gbMedicalHistory.Controls.Add(this.label6);
            this.gbMedicalHistory.Controls.Add(this.label7);
            this.gbMedicalHistory.Controls.Add(this.label8);
            this.gbMedicalHistory.Controls.Add(this.label9);
            this.gbMedicalHistory.Controls.Add(this.label10);
            this.gbMedicalHistory.Controls.Add(this.gbWomen);
            this.gbMedicalHistory.Controls.Add(this.gbAllergies);
            this.gbMedicalHistory.Location = new System.Drawing.Point(12, 34);
            this.gbMedicalHistory.Name = "gbMedicalHistory";
            this.gbMedicalHistory.Size = new System.Drawing.Size(991, 302);
            this.gbMedicalHistory.TabIndex = 0;
            this.gbMedicalHistory.TabStop = false;
            this.gbMedicalHistory.Text = "Medical History";
            // 
            // gbAllergies
            // 
            this.gbAllergies.Controls.Add(this.textBox5);
            this.gbAllergies.Controls.Add(this.checkBox7);
            this.gbAllergies.Controls.Add(this.label19);
            this.gbAllergies.Controls.Add(this.checkBox1);
            this.gbAllergies.Controls.Add(this.checkBox6);
            this.gbAllergies.Controls.Add(this.checkBox2);
            this.gbAllergies.Controls.Add(this.checkBox5);
            this.gbAllergies.Controls.Add(this.checkBox3);
            this.gbAllergies.Controls.Add(this.checkBox4);
            this.gbAllergies.Location = new System.Drawing.Point(720, 16);
            this.gbAllergies.Name = "gbAllergies";
            this.gbAllergies.Size = new System.Drawing.Size(260, 269);
            this.gbAllergies.TabIndex = 0;
            this.gbAllergies.TabStop = false;
            this.gbAllergies.Text = "Allergies";
            // 
            // gbWomen
            // 
            this.gbWomen.Controls.Add(this.checkBox12);
            this.gbWomen.Controls.Add(this.checkBox11);
            this.gbWomen.Controls.Add(this.checkBox10);
            this.gbWomen.Controls.Add(this.checkBox9);
            this.gbWomen.Controls.Add(this.checkBox8);
            this.gbWomen.Location = new System.Drawing.Point(19, 226);
            this.gbWomen.Name = "gbWomen";
            this.gbWomen.Size = new System.Drawing.Size(671, 70);
            this.gbWomen.TabIndex = 0;
            this.gbWomen.TabStop = false;
            this.gbWomen.Text = "Women:";
            // 
            // gbIllnesses
            // 
            this.gbIllnesses.Controls.Add(this.label48);
            this.gbIllnesses.Controls.Add(this.label27);
            this.gbIllnesses.Controls.Add(this.label26);
            this.gbIllnesses.Controls.Add(this.label25);
            this.gbIllnesses.Controls.Add(this.label24);
            this.gbIllnesses.Controls.Add(this.label23);
            this.gbIllnesses.Controls.Add(this.label22);
            this.gbIllnesses.Controls.Add(this.label21);
            this.gbIllnesses.Controls.Add(this.label18);
            this.gbIllnesses.Controls.Add(this.label17);
            this.gbIllnesses.Controls.Add(this.label16);
            this.gbIllnesses.Controls.Add(this.label15);
            this.gbIllnesses.Controls.Add(this.label14);
            this.gbIllnesses.Controls.Add(this.label12);
            this.gbIllnesses.Controls.Add(this.button3);
            this.gbIllnesses.Location = new System.Drawing.Point(12, 342);
            this.gbIllnesses.Name = "gbIllnesses";
            this.gbIllnesses.Size = new System.Drawing.Size(980, 337);
            this.gbIllnesses.TabIndex = 0;
            this.gbIllnesses.TabStop = false;
            this.gbIllnesses.Text = "Illness / Disease Tracking";
            // 
            // radioButton113
            // 
            this.radioButton113.AutoSize = true;
            this.radioButton113.Location = new System.Drawing.Point(331, 171);
            this.radioButton113.Name = "radioButton113";
            this.radioButton113.Size = new System.Drawing.Size(39, 17);
            this.radioButton113.TabIndex = 245;
            this.radioButton113.TabStop = true;
            this.radioButton113.Text = "No";
            this.radioButton113.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(428, 145);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(241, 20);
            this.textBox6.TabIndex = 231;
            // 
            // radioButton114
            // 
            this.radioButton114.AutoSize = true;
            this.radioButton114.Location = new System.Drawing.Point(273, 171);
            this.radioButton114.Name = "radioButton114";
            this.radioButton114.Size = new System.Drawing.Size(43, 17);
            this.radioButton114.TabIndex = 244;
            this.radioButton114.TabStop = true;
            this.radioButton114.Text = "Yes";
            this.radioButton114.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(390, 148);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(32, 13);
            this.label49.TabIndex = 230;
            this.label49.Text = "If yes";
            // 
            // radioButton115
            // 
            this.radioButton115.AutoSize = true;
            this.radioButton115.Location = new System.Drawing.Point(331, 146);
            this.radioButton115.Name = "radioButton115";
            this.radioButton115.Size = new System.Drawing.Size(39, 17);
            this.radioButton115.TabIndex = 243;
            this.radioButton115.TabStop = true;
            this.radioButton115.Text = "No";
            this.radioButton115.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(428, 69);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(242, 18);
            this.textBox4.TabIndex = 229;
            // 
            // radioButton116
            // 
            this.radioButton116.AutoSize = true;
            this.radioButton116.Location = new System.Drawing.Point(273, 146);
            this.radioButton116.Name = "radioButton116";
            this.radioButton116.Size = new System.Drawing.Size(43, 17);
            this.radioButton116.TabIndex = 242;
            this.radioButton116.TabStop = true;
            this.radioButton116.Text = "Yes";
            this.radioButton116.UseVisualStyleBackColor = true;
            // 
            // radioButton117
            // 
            this.radioButton117.AutoSize = true;
            this.radioButton117.Location = new System.Drawing.Point(331, 122);
            this.radioButton117.Name = "radioButton117";
            this.radioButton117.Size = new System.Drawing.Size(39, 17);
            this.radioButton117.TabIndex = 241;
            this.radioButton117.TabStop = true;
            this.radioButton117.Text = "No";
            this.radioButton117.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(428, 42);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(242, 20);
            this.textBox2.TabIndex = 227;
            // 
            // radioButton118
            // 
            this.radioButton118.AutoSize = true;
            this.radioButton118.Location = new System.Drawing.Point(271, 122);
            this.radioButton118.Name = "radioButton118";
            this.radioButton118.Size = new System.Drawing.Size(43, 17);
            this.radioButton118.TabIndex = 240;
            this.radioButton118.TabStop = true;
            this.radioButton118.Text = "Yes";
            this.radioButton118.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(428, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(242, 20);
            this.textBox1.TabIndex = 226;
            // 
            // radioButton119
            // 
            this.radioButton119.AutoSize = true;
            this.radioButton119.Location = new System.Drawing.Point(331, 95);
            this.radioButton119.Name = "radioButton119";
            this.radioButton119.Size = new System.Drawing.Size(39, 17);
            this.radioButton119.TabIndex = 239;
            this.radioButton119.TabStop = true;
            this.radioButton119.Text = "No";
            this.radioButton119.UseVisualStyleBackColor = true;
            // 
            // radioButton120
            // 
            this.radioButton120.AutoSize = true;
            this.radioButton120.Location = new System.Drawing.Point(273, 95);
            this.radioButton120.Name = "radioButton120";
            this.radioButton120.Size = new System.Drawing.Size(43, 17);
            this.radioButton120.TabIndex = 238;
            this.radioButton120.TabStop = true;
            this.radioButton120.Text = "Yes";
            this.radioButton120.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(273, 197);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 225;
            // 
            // radioButton121
            // 
            this.radioButton121.AutoSize = true;
            this.radioButton121.Location = new System.Drawing.Point(331, 70);
            this.radioButton121.Name = "radioButton121";
            this.radioButton121.Size = new System.Drawing.Size(39, 17);
            this.radioButton121.TabIndex = 237;
            this.radioButton121.TabStop = true;
            this.radioButton121.Text = "No";
            this.radioButton121.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 13);
            this.label1.TabIndex = 215;
            this.label1.Text = "Have you been hospitalized or had a major surgery?";
            // 
            // radioButton122
            // 
            this.radioButton122.AutoSize = true;
            this.radioButton122.Location = new System.Drawing.Point(273, 70);
            this.radioButton122.Name = "radioButton122";
            this.radioButton122.Size = new System.Drawing.Size(43, 17);
            this.radioButton122.TabIndex = 236;
            this.radioButton122.TabStop = true;
            this.radioButton122.Text = "Yes";
            this.radioButton122.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(390, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 216;
            this.label2.Text = "If yes";
            // 
            // radioButton123
            // 
            this.radioButton123.AutoSize = true;
            this.radioButton123.Location = new System.Drawing.Point(331, 41);
            this.radioButton123.Name = "radioButton123";
            this.radioButton123.Size = new System.Drawing.Size(39, 17);
            this.radioButton123.TabIndex = 235;
            this.radioButton123.TabStop = true;
            this.radioButton123.Text = "No";
            this.radioButton123.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(96, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 13);
            this.label3.TabIndex = 217;
            this.label3.Text = "Have you had any serious injuries?";
            // 
            // radioButton124
            // 
            this.radioButton124.AutoSize = true;
            this.radioButton124.Location = new System.Drawing.Point(273, 43);
            this.radioButton124.Name = "radioButton124";
            this.radioButton124.Size = new System.Drawing.Size(43, 17);
            this.radioButton124.TabIndex = 234;
            this.radioButton124.TabStop = true;
            this.radioButton124.Text = "Yes";
            this.radioButton124.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(390, 72);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 13);
            this.label20.TabIndex = 228;
            this.label20.Text = "If yes";
            // 
            // radioButton125
            // 
            this.radioButton125.AutoSize = true;
            this.radioButton125.Location = new System.Drawing.Point(331, 17);
            this.radioButton125.Name = "radioButton125";
            this.radioButton125.Size = new System.Drawing.Size(39, 17);
            this.radioButton125.TabIndex = 233;
            this.radioButton125.TabStop = true;
            this.radioButton125.Text = "No";
            this.radioButton125.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(390, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 218;
            this.label4.Text = "If yes";
            // 
            // radioButton126
            // 
            this.radioButton126.AutoSize = true;
            this.radioButton126.Location = new System.Drawing.Point(273, 17);
            this.radioButton126.Name = "radioButton126";
            this.radioButton126.Size = new System.Drawing.Size(43, 17);
            this.radioButton126.TabIndex = 232;
            this.radioButton126.TabStop = true;
            this.radioButton126.Text = "Yes";
            this.radioButton126.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 13);
            this.label5.TabIndex = 219;
            this.label5.Text = "Are you taking any medication?";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(138, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 13);
            this.label6.TabIndex = 220;
            this.label6.Text = "Are you on a special diet?";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(158, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 13);
            this.label7.TabIndex = 221;
            this.label7.Text = "Do you use tobacco?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(94, 148);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(173, 13);
            this.label8.TabIndex = 222;
            this.label8.Text = "Do you use controlled substances?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(146, 173);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 13);
            this.label9.TabIndex = 223;
            this.label9.Text = "Are you sexually active?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(128, 200);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(139, 13);
            this.label10.TabIndex = 224;
            this.label10.Text = "How often do you exercise?";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(428, 94);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(242, 18);
            this.textBox3.TabIndex = 247;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(390, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 13);
            this.label11.TabIndex = 246;
            this.label11.Text = "If yes";
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(484, 31);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(68, 17);
            this.checkBox12.TabIndex = 47;
            this.checkBox12.Text = "Nursing?";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(258, 42);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(136, 17);
            this.checkBox11.TabIndex = 46;
            this.checkBox11.Text = "Trying to get pregnant?";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(258, 19);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(205, 17);
            this.checkBox10.TabIndex = 45;
            this.checkBox10.Text = "Thinking of taking oral contraceptive?";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(67, 42);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(75, 17);
            this.checkBox9.TabIndex = 43;
            this.checkBox9.Text = "Pregnant?";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(67, 19);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(153, 17);
            this.checkBox8.TabIndex = 44;
            this.checkBox8.Text = "Taking oral contraceptive?";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(24, 143);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(209, 115);
            this.textBox5.TabIndex = 46;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(24, 119);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(52, 17);
            this.checkBox7.TabIndex = 47;
            this.checkBox7.Text = "Other";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(191, 13);
            this.label19.TabIndex = 39;
            this.label19.Text = "Are you allergic to any of the following?";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(24, 40);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(67, 17);
            this.checkBox1.TabIndex = 40;
            this.checkBox1.Text = "Penicillin";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(140, 67);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(74, 17);
            this.checkBox6.TabIndex = 45;
            this.checkBox6.Text = "Chemicals";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(24, 67);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(55, 17);
            this.checkBox2.TabIndex = 41;
            this.checkBox2.Text = "Asprin";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(140, 40);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(81, 17);
            this.checkBox5.TabIndex = 44;
            this.checkBox5.Text = "Sulfa Drugs";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(24, 92);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(52, 17);
            this.checkBox3.TabIndex = 42;
            this.checkBox3.Text = "Latex";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(139, 92);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(110, 17);
            this.checkBox4.TabIndex = 43;
            this.checkBox4.Text = "Local Anesthetics";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(782, 685);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Add History";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(891, 685);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Update History";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(878, 267);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "Track Illness";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(268, 154);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(75, 13);
            this.label48.TabIndex = 47;
            this.label48.Text = "Chemotherapy";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(268, 133);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 13);
            this.label27.TabIndex = 46;
            this.label27.Text = "Cancer";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(268, 108);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 13);
            this.label26.TabIndex = 45;
            this.label26.Text = "Bruise Easily";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(268, 86);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 13);
            this.label25.TabIndex = 44;
            this.label25.Text = "Breathing Problem";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(268, 62);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(92, 13);
            this.label24.TabIndex = 43;
            this.label24.Text = "Blood Transfusion";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(268, 38);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 13);
            this.label23.TabIndex = 42;
            this.label23.Text = "Blood Disease";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(42, 201);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 13);
            this.label22.TabIndex = 41;
            this.label22.Text = "Asthma";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(42, 177);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 13);
            this.label21.TabIndex = 40;
            this.label21.Text = "Artificial Joint";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(42, 153);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(102, 13);
            this.label18.TabIndex = 39;
            this.label18.Text = "Artificial Heart Valve";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(42, 129);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 13);
            this.label17.TabIndex = 38;
            this.label17.Text = "Arthritis/Gout";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(42, 105);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 37;
            this.label16.Text = "Angina";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(42, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 13);
            this.label15.TabIndex = 36;
            this.label15.Text = "Anaphylaxis";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Alzheimer\'s Disease";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 13);
            this.label12.TabIndex = 34;
            this.label12.Text = "AIDS/HIV";
            // 
            // MedicalHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 756);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gbIllnesses);
            this.Controls.Add(this.gbMedicalHistory);
            this.Name = "MedicalHistory";
            this.Text = "MedicalHistory";
            this.gbMedicalHistory.ResumeLayout(false);
            this.gbMedicalHistory.PerformLayout();
            this.gbAllergies.ResumeLayout(false);
            this.gbAllergies.PerformLayout();
            this.gbWomen.ResumeLayout(false);
            this.gbWomen.PerformLayout();
            this.gbIllnesses.ResumeLayout(false);
            this.gbIllnesses.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbMedicalHistory;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton radioButton113;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.RadioButton radioButton114;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RadioButton radioButton115;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.RadioButton radioButton116;
        private System.Windows.Forms.RadioButton radioButton117;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton radioButton118;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton radioButton119;
        private System.Windows.Forms.RadioButton radioButton120;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton radioButton121;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton122;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButton123;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton124;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton radioButton125;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButton126;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox gbWomen;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.GroupBox gbAllergies;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.GroupBox gbIllnesses;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}